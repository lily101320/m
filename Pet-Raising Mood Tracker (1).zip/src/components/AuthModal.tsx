import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface AuthModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAuthSuccess: (accessToken: string) => void;
}

export function AuthModal({ open, onOpenChange, onAuthSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    setLoading(true);
    setError('');

    try {
      const { createClient } = await import('../utils/supabase/client');
      const supabase = createClient();

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        setError(error.message);
        setLoading(false);
        return;
      }

      if (data?.session?.access_token) {
        onAuthSuccess(data.session.access_token);
        onOpenChange(false);
        setEmail('');
        setPassword('');
        setName('');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('登录失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    setLoading(true);
    setError('');

    try {
      const { projectId, publicAnonKey } = await import('../utils/supabase/info');
      
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-383a7eab/signup`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ email, password, name }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        setError(result.error || '注册失败');
        setLoading(false);
        return;
      }

      // After signup, automatically login
      await handleLogin();
    } catch (err) {
      console.error('Signup error:', err);
      setError('注册失败，请重试');
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'login') {
      await handleLogin();
    } else {
      await handleSignup();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black border-4 border-[#FFD700] text-[#FFD700]">
        <DialogHeader>
          <DialogTitle className="text-2xl text-[#FFD700]" style={{ fontFamily: 'monospace' }}>
            {mode === 'login' ? '登录' : '注册'}
          </DialogTitle>
          <DialogDescription className="text-[#FFD700]/75" style={{ fontFamily: 'monospace' }}>
            {mode === 'login' ? '登录以同步你的心情记录' : '创建账号以保存你的数据'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {mode === 'signup' && (
            <div>
              <label className="text-sm opacity-75 mb-2 block" style={{ fontFamily: 'monospace' }}>
                昵称
              </label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="输入你的昵称"
                className="bg-[#FFD700]/10 border-4 border-[#FFD700] text-[#FFD700] placeholder:text-[#FFD700]/50"
                style={{ fontFamily: 'monospace' }}
              />
            </div>
          )}

          <div>
            <label className="text-sm opacity-75 mb-2 block" style={{ fontFamily: 'monospace' }}>
              邮箱
            </label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="输入邮箱"
              required
              className="bg-[#FFD700]/10 border-4 border-[#FFD700] text-[#FFD700] placeholder:text-[#FFD700]/50"
              style={{ fontFamily: 'monospace' }}
            />
          </div>

          <div>
            <label className="text-sm opacity-75 mb-2 block" style={{ fontFamily: 'monospace' }}>
              密码
            </label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="输入密码"
              required
              className="bg-[#FFD700]/10 border-4 border-[#FFD700] text-[#FFD700] placeholder:text-[#FFD700]/50"
              style={{ fontFamily: 'monospace' }}
            />
          </div>

          {error && (
            <div className="text-red-400 text-sm" style={{ fontFamily: 'monospace' }}>
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#FFD700] text-black hover:bg-[#FF8C00] border-4 border-[#FFD700] hover:border-[#FF8C00]"
              style={{ fontFamily: 'monospace' }}
            >
              {loading ? '处理中...' : mode === 'login' ? '登录' : '注册'}
            </Button>
          </div>

          <div className="text-center">
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'signup' : 'login');
                setError('');
              }}
              className="text-sm underline hover:text-[#FF8C00] transition-all"
              style={{ fontFamily: 'monospace' }}
            >
              {mode === 'login' ? '没有账号？注册' : '已有账号？登录'}
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
