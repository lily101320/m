import { Plus, ShoppingCart, Heart, Clock } from 'lucide-react';

interface NavigationProps {
  currentTab: 'home' | 'shop' | 'pet' | 'history';
  onTabChange: (tab: 'home' | 'shop' | 'pet' | 'history') => void;
}

export function Navigation({ currentTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'home' as const, label: '记录', icon: Plus },
    { id: 'shop' as const, label: '购物', icon: ShoppingCart },
    { id: 'pet' as const, label: '宠物', icon: Heart },
    { id: 'history' as const, label: '历史记录', icon: Clock },
  ];

  return (
    <nav className="border-t-4 border-[#FFD700] bg-black px-4 py-3">
      <div className="max-w-md mx-auto grid grid-cols-4 gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center gap-1 p-2 transition-all ${
                isActive ? 'text-[#FF8C00]' : 'text-[#FFD700] hover:text-[#FF8C00]'
              }`}
            >
              <div className={`w-12 h-12 rounded-full border-4 flex items-center justify-center ${
                isActive ? 'border-[#FF8C00] bg-[#FF8C00]/20' : 'border-[#FFD700]'
              }`}>
                <Icon className="w-6 h-6" strokeWidth={3} style={{ imageRendering: 'pixelated' }} />
              </div>
              <span className="text-xs" style={{ fontFamily: 'monospace' }}>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
