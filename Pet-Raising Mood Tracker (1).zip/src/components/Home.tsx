import { useState } from 'react';
import { Coins, User, LogOut } from 'lucide-react';
import { MoodType } from '../App';
import { AuthModal } from './AuthModal';
import image1 from 'figma:asset/b7b751701688fe21c889ffd06d57aeaea1a47d97.png';

interface HomeProps {
  coins: number;
  onAddMood: (mood: MoodType) => void;
  isLoggedIn: boolean;
  userEmail: string | null;
  onLogin: (token: string) => void;
  onLogout: () => void;
}

export function Home({ coins, onAddMood, isLoggedIn, userEmail, onLogin, onLogout }: HomeProps) {
  const [showMoodSelector, setShowMoodSelector] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const moods: { type: MoodType; label: string; emoji: string }[] = [
    { type: 'happy', label: '开心', emoji: '😊' },
    { type: 'sad', label: '难过', emoji: '😢' },
    { type: 'angry', label: '生气', emoji: '😠' },
    { type: 'calm', label: '平静', emoji: '😌' },
    { type: 'excited', label: '兴奋', emoji: '🤩' },
    { type: 'anxious', label: '焦虑', emoji: '😰' },
  ];

  const handleMoodSelect = (mood: MoodType) => {
    onAddMood(mood);
    setShowMoodSelector(false);
  };

  return (
    <div className="min-h-full flex flex-col relative">
      {/* Header with Coin Display and Login */}
      <div className="flex items-center justify-between p-6">
        <div className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-full border-4 border-[#FFD700] bg-[#FFD700]/20 flex items-center justify-center">
            <Coins className="w-8 h-8 text-[#FFD700]" strokeWidth={3} />
          </div>
          <div className="text-2xl" style={{ fontFamily: 'monospace' }}>{coins} mb</div>
        </div>
        
        {isLoggedIn ? (
          <div className="flex items-center gap-2">
            <div className="text-sm opacity-75 max-w-[120px] truncate" style={{ fontFamily: 'monospace' }}>
              {userEmail}
            </div>
            <button
              onClick={onLogout}
              className="w-10 h-10 rounded-full border-4 border-[#FFD700] bg-[#FFD700]/20 flex items-center justify-center hover:bg-[#FF8C00]/20 hover:border-[#FF8C00] transition-all"
              title="登出"
            >
              <LogOut className="w-5 h-5 text-[#FFD700]" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setShowAuthModal(true)}
            className="px-4 py-2 rounded-full border-4 border-[#FFD700] bg-[#FFD700]/20 hover:bg-[#FF8C00]/20 hover:border-[#FF8C00] transition-all flex items-center gap-2"
          >
            <User className="w-5 h-5 text-[#FFD700]" />
            <span style={{ fontFamily: 'monospace' }}>登录</span>
          </button>
        )}
      </div>

      <AuthModal
        open={showAuthModal}
        onOpenChange={setShowAuthModal}
        onAuthSuccess={onLogin}
      />

      {/* Content positioned at 380px from top */}
      <div className="px-6" style={{ marginTop: '380px' }}>
        {!showMoodSelector ? (
          <div className="flex flex-col items-center gap-8">
            <h1 className="text-4xl text-center" style={{ fontFamily: 'monospace' }}>
              现在心情怎么样?
            </h1>
            
            <button
              onClick={() => setShowMoodSelector(true)}
              className="w-20 h-20 rounded-full border-4 border-[#FFD700] bg-[#FFD700]/20 flex items-center justify-center hover:bg-[#FF8C00]/20 hover:border-[#FF8C00] transition-all"
            >
              <Plus className="w-10 h-10 text-[#FFD700]" strokeWidth={4} />
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-8 w-full max-w-md mx-auto">
            <h2 className="text-3xl" style={{ fontFamily: 'monospace' }}>选择心情</h2>
            
            <div className="grid grid-cols-2 gap-4 w-full">
              {moods.map((mood) => (
                <button
                  key={mood.type}
                  onClick={() => handleMoodSelect(mood.type)}
                  className="bg-[#FFD700] text-black p-6 rounded-3xl hover:bg-[#FF8C00] transition-all border-4 border-[#FFD700] hover:border-[#FF8C00] flex flex-col items-center gap-2"
                >
                  <span className="text-4xl">{mood.emoji}</span>
                  <span className="text-xl" style={{ fontFamily: 'monospace' }}>{mood.label}</span>
                </button>
              ))}
            </div>
            
            <button
              onClick={() => setShowMoodSelector(false)}
              className="text-xl underline hover:text-[#FF8C00] transition-all"
              style={{ fontFamily: 'monospace' }}
            >
              取消
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Plus({ className, strokeWidth }: { className?: string; strokeWidth?: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth || 2}
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={className}
      style={{ imageRendering: 'pixelated' }}
    >
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}
