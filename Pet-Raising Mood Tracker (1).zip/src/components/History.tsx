import { MoodRecord } from '../App';
import { Calendar } from 'lucide-react';

interface HistoryProps {
  records: MoodRecord[];
}

export function History({ records }: HistoryProps) {
  const getMoodEmoji = (mood: string) => {
    const emojiMap: Record<string, string> = {
      happy: '😊',
      sad: '😢',
      angry: '😠',
      calm: '😌',
      excited: '🤩',
      anxious: '😰',
    };
    return emojiMap[mood] || '😐';
  };

  const getMoodLabel = (mood: string) => {
    const labelMap: Record<string, string> = {
      happy: '开心',
      sad: '难过',
      angry: '生气',
      calm: '平静',
      excited: '兴奋',
      anxious: '焦虑',
    };
    return labelMap[mood] || mood;
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const recordDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - recordDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - recordDate.getTime()) / (1000 * 60));
      return `${diffInMinutes}分钟前`;
    } else if (diffInHours < 24) {
      return `${diffInHours}小时前`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}天前`;
    }
  };

  return (
    <div className="min-h-full p-6">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-center mb-8 pt-4">
          <div className="border-4 border-[#FFD700] rounded-full px-8 py-3 flex items-center gap-3">
            <Calendar className="w-8 h-8 text-[#FFD700]" />
            <h1 className="text-3xl" style={{ fontFamily: 'monospace' }}>心情记录</h1>
          </div>
        </div>

        {/* Records */}
        {records.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-2xl opacity-50" style={{ fontFamily: 'monospace' }}>
              还没有记录
            </p>
            <p className="text-xl opacity-50 mt-4" style={{ fontFamily: 'monospace' }}>
              开始记录你的心情吧！
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {records.map((record) => (
              <div
                key={record.id}
                className="bg-[#FFD700]/10 border-4 border-[#FFD700] rounded-3xl p-6 flex items-center gap-4"
              >
                <div className="text-5xl">{getMoodEmoji(record.mood)}</div>
                <div className="flex-1">
                  <div className="text-2xl mb-1" style={{ fontFamily: 'monospace' }}>
                    {getMoodLabel(record.mood)}
                  </div>
                  <div className="text-lg opacity-75" style={{ fontFamily: 'monospace' }}>
                    {formatDate(record.timestamp)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl text-[#FF8C00]" style={{ fontFamily: 'monospace' }}>
                    +{record.coinsEarned} mb
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
