import { PetState } from '../App';
import { Heart, Drumstick, Edit2 } from 'lucide-react';
import { Progress } from './ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { useState } from 'react';
import image3 from 'figma:asset/0dda729d882c57d0a2eb93583a479cd4d25458bc.png';

interface PetProps {
  petState: PetState;
  petName: string;
  onNameChange: (name: string) => void;
}

export function Pet({ petState, petName, onNameChange }: PetProps) {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(petName);
  const getPetEmoji = (appearance: string) => {
    const emojiMap: Record<string, string> = {
      neutral: '🐱',
      joyful: '😺',
      melancholic: '😿',
      fiery: '😾',
      serene: '😸',
      energetic: '😹',
      nervous: '🙀',
    };
    return emojiMap[appearance] || '🐱';
  };

  const getPersonalityDescription = (personality: string) => {
    const descriptions: Record<string, string> = {
      balanced: '性格平衡，温和友善',
      cheerful: '开朗活泼，充满阳光',
      sensitive: '细腻敏感，需要关爱',
      passionate: '热情如火，充满活力',
      peaceful: '平和宁静，岁月静好',
      playful: '调皮好动，活力四射',
      cautious: '谨慎小心，需要安抚',
    };
    return descriptions[personality] || '性格独特';
  };

  const handleSaveName = () => {
    if (tempName.trim()) {
      onNameChange(tempName.trim());
      setIsEditingName(false);
    }
  };

  return (
    <div className="min-h-full p-6 flex flex-col items-center justify-center">
      <div className="max-w-md w-full space-y-8">
        {/* Pet Display */}
        <div className="flex flex-col items-center gap-6">
          <div className="w-48 h-48 rounded-full border-8 border-[#FF8C00] bg-[#FF8C00]/20 flex items-center justify-center">
            <div className="text-9xl animate-bounce">{getPetEmoji(petState.appearance)}</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-2">
              <h2 className="text-3xl" style={{ fontFamily: 'monospace' }}>
                {petName}
              </h2>
              <Dialog open={isEditingName} onOpenChange={setIsEditingName}>
                <DialogTrigger asChild>
                  <button
                    onClick={() => {
                      setTempName(petName);
                      setIsEditingName(true);
                    }}
                    className="w-10 h-10 rounded-full border-4 border-[#FFD700] bg-[#FFD700]/20 flex items-center justify-center hover:bg-[#FF8C00]/20 hover:border-[#FF8C00] transition-all"
                  >
                    <Edit2 className="w-5 h-5 text-[#FFD700]" />
                  </button>
                </DialogTrigger>
                <DialogContent className="bg-black border-4 border-[#FFD700] text-[#FFD700]">
                  <DialogHeader>
                    <DialogTitle className="text-2xl text-[#FFD700]" style={{ fontFamily: 'monospace' }}>
                      给宠物取名
                    </DialogTitle>
                    <DialogDescription className="text-[#FFD700]/75" style={{ fontFamily: 'monospace' }}>
                      为你的宠物选择一个独特的名字
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <Input
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      placeholder="输入宠物的名字"
                      maxLength={20}
                      className="bg-[#FFD700]/10 border-4 border-[#FFD700] text-[#FFD700] placeholder:text-[#FFD700]/50 text-xl"
                      style={{ fontFamily: 'monospace' }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleSaveName();
                        }
                      }}
                    />
                    <div className="flex gap-3">
                      <Button
                        onClick={() => setIsEditingName(false)}
                        variant="outline"
                        className="flex-1 border-4 border-[#FFD700] bg-transparent text-[#FFD700] hover:bg-[#FFD700]/20 text-xl"
                        style={{ fontFamily: 'monospace' }}
                      >
                        取消
                      </Button>
                      <Button
                        onClick={handleSaveName}
                        className="flex-1 bg-[#FFD700] text-black hover:bg-[#FF8C00] border-4 border-[#FFD700] hover:border-[#FF8C00] text-xl"
                        style={{ fontFamily: 'monospace' }}
                      >
                        保存
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <p className="text-xl opacity-75" style={{ fontFamily: 'monospace' }}>
              {getPersonalityDescription(petState.personality)}
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="space-y-6 bg-[#FFD700]/10 border-4 border-[#FFD700] rounded-3xl p-6">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Heart className="w-6 h-6 text-[#FFD700]" fill="currentColor" />
                <span className="text-xl" style={{ fontFamily: 'monospace' }}>快乐值</span>
              </div>
              <span className="text-xl" style={{ fontFamily: 'monospace' }}>{petState.happiness}%</span>
            </div>
            <Progress value={petState.happiness} className="h-4" />
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Drumstick className="w-6 h-6 text-[#FFD700]" />
                <span className="text-xl" style={{ fontFamily: 'monospace' }}>饱腹度</span>
              </div>
              <span className="text-xl" style={{ fontFamily: 'monospace' }}>{petState.hunger}%</span>
            </div>
            <Progress value={petState.hunger} className="h-4" />
          </div>
        </div>

        {/* Info */}
        <div className="text-center opacity-75">
          <p className="text-lg" style={{ fontFamily: 'monospace' }}>
            记录心情来照顾你的宠物吧！
          </p>
        </div>
      </div>
    </div>
  );
}
