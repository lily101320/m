import { ShopItem } from '../App';
import image2 from 'figma:asset/7d589d426d304e25ba25228cbfeed6dfd6fff1f5.png';

interface ShopProps {
  coins: number;
  onBuyItem: (item: ShopItem) => void;
}

export function Shop({ coins, onBuyItem }: ShopProps) {
  const shopItems: ShopItem[] = [
    {
      id: '1',
      name: '鸡',
      icon: '🍗',
      price: 10,
      effect: { hunger: 30, happiness: 10 },
    },
    {
      id: '2',
      name: '鱼',
      icon: '🐟',
      price: 10,
      effect: { hunger: 25, happiness: 15 },
    },
    {
      id: '3',
      name: '牛奶',
      icon: '🥛',
      price: 30,
      effect: { hunger: 40, happiness: 20 },
    },
    {
      id: '4',
      name: '玩具',
      icon: '🎾',
      price: 25,
      effect: { happiness: 30 },
    },
    {
      id: '5',
      name: '零食',
      icon: '🍪',
      price: 15,
      effect: { hunger: 20, happiness: 25 },
    },
    {
      id: '6',
      name: '水果',
      icon: '🍎',
      price: 20,
      effect: { hunger: 35, happiness: 15 },
    },
  ];

  return (
    <div className="min-h-full p-6">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-center mb-8 pt-4">
          <div className="border-4 border-[#FFD700] rounded-full px-8 py-3">
            <h1 className="text-3xl" style={{ fontFamily: 'monospace' }}>食物</h1>
          </div>
        </div>

        {/* Coins Display */}
        <div className="text-center mb-8 text-2xl" style={{ fontFamily: 'monospace' }}>
          余额: {coins} mb
        </div>

        {/* Shop Items */}
        <div className="space-y-4">
          {shopItems.map((item) => {
            const canAfford = coins >= item.price;
            
            return (
              <button
                key={item.id}
                onClick={() => canAfford && onBuyItem(item)}
                disabled={!canAfford}
                className={`w-full bg-[#FFD700] text-black rounded-3xl border-4 border-[#FFD700] p-6 flex items-center gap-4 transition-all ${
                  canAfford
                    ? 'hover:bg-[#FF8C00] hover:border-[#FF8C00] cursor-pointer'
                    : 'opacity-50 cursor-not-allowed'
                }`}
              >
                <div className="text-5xl">{item.icon}</div>
                <div className="flex-1 text-left">
                  <div className="text-2xl" style={{ fontFamily: 'monospace' }}>
                    {item.name}
                  </div>
                  <div className="text-xl opacity-75" style={{ fontFamily: 'monospace' }}>
                    {item.price} mb
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
