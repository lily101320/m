import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors());
app.use('*', logger(console.log));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Sign up new user
app.post('/make-server-383a7eab/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Initialize user data
    const userId = data.user.id;
    await kv.set(`user:${userId}:coins`, 100);
    await kv.set(`user:${userId}:petName`, 'WindSong');
    await kv.set(`user:${userId}:petState`, {
      appearance: 'neutral',
      personality: 'balanced',
      happiness: 50,
      hunger: 50,
    });
    await kv.set(`user:${userId}:moodRecords`, []);

    return c.json({ success: true, user: data.user });
  } catch (error) {
    console.log('Signup error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Get user data
app.get('/make-server-383a7eab/user-data', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Unauthorized: No access token provided' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      console.log('Auth error while getting user data:', error);
      return c.json({ error: 'Unauthorized: Invalid access token' }, 401);
    }

    const userId = user.id;
    const coins = await kv.get(`user:${userId}:coins`) || 100;
    const petName = await kv.get(`user:${userId}:petName`) || 'WindSong';
    const petState = await kv.get(`user:${userId}:petState`) || {
      appearance: 'neutral',
      personality: 'balanced',
      happiness: 50,
      hunger: 50,
    };
    const moodRecords = await kv.get(`user:${userId}:moodRecords`) || [];

    return c.json({
      coins,
      petName,
      petState,
      moodRecords,
      user: {
        email: user.email,
        name: user.user_metadata?.name,
      },
    });
  } catch (error) {
    console.log('Error fetching user data:', error);
    return c.json({ error: 'Internal server error while fetching user data' }, 500);
  }
});

// Save user data
app.post('/make-server-383a7eab/save-data', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    if (!accessToken) {
      return c.json({ error: 'Unauthorized: No access token provided' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    if (error || !user) {
      console.log('Auth error while saving data:', error);
      return c.json({ error: 'Unauthorized: Invalid access token' }, 401);
    }

    const { coins, petName, petState, moodRecords } = await c.req.json();
    const userId = user.id;

    await kv.set(`user:${userId}:coins`, coins);
    await kv.set(`user:${userId}:petName`, petName);
    await kv.set(`user:${userId}:petState`, petState);
    await kv.set(`user:${userId}:moodRecords`, moodRecords);

    return c.json({ success: true });
  } catch (error) {
    console.log('Error saving user data:', error);
    return c.json({ error: 'Internal server error while saving data' }, 500);
  }
});

Deno.serve(app.fetch);
