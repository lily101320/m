
  # Pet-Raising Mood Tracker

  This is a code bundle for Pet-Raising Mood Tracker. The original project is available at https://www.figma.com/design/N5qd0aqaPQY0JTMA5W41TP/Pet-Raising-Mood-Tracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  